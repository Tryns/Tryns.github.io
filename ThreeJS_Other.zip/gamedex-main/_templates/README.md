# 📦 Minimal Project Templates

This folder contains templates for quickly running game dev experiments.
